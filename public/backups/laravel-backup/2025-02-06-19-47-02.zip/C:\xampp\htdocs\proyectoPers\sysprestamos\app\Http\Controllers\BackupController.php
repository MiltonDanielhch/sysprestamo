<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class BackupController extends Controller
{
    // public function index(){
    //     $backups = Storage::disk('backups')->files();
    //     print_r($backups);
    //     return view('admin.backups.index', compact('backups'));
    // }

    public function index() {
        $disk = Storage::disk('backups');
        $backups = collect($disk->files())->map(function($file) use ($disk) {
            return [
                'nombre' => $file,
                'tamaño' => $disk->size($file),
                'fecha' => $disk->lastModified($file)
            ];
        })->sortByDesc('fecha');

        return view('admin.backups.index', ['backups' => $backups]);
    }

    // public function create()
    // {
    //     try {
    //         Artisan::call('backup:run');
    //         return redirect()->back()->with('mensaje', 'Backup creado exitosamente.')->with('icono', 'success');
    //     } catch (\Exception $e) {
    //         return redirect()->back()->with('error', 'Error al crear el backup: ' . $e->getMessage());
    //     }
    // }
    public function create()
    {
        try {
            Artisan::call('backup:run');

            // Obtener la salida del comando
            $output = Artisan::output();

            // Registrar en logs
            \Log::info('Backup output: ' . $output);

            return redirect()->route('admin.backups.index')
                ->with('mensaje', 'Backup creado: ' . $output)
                ->with('icono', 'success');

        } catch (\Exception $e) {
            \Log::error('Backup error: ' . $e->getMessage());
            return redirect()->route('admin.backups.index')
                ->with('mensaje', 'ERROR: ' . $e->getMessage())
                ->with('icono', 'error');
        }
    }


}
