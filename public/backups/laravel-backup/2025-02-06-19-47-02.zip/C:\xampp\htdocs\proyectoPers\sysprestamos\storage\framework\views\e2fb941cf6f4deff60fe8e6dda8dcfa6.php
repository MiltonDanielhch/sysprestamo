<?php $__env->startSection('content_header'); ?>
    <h1 class="text-primary"><i class="fas fa-user-tag mr-2"></i><b>Roles/Asignar Permisos al <?php echo e($rol->name); ?></b></h1>
    <hr class="bg-primary">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12 col-lg-12">
            <div class="card card-outline card-primary shadow">
                <div class="card-header bg-white">
                    <h3 class="card-title">
                        <i class="fas fa-plus-circle text-primary mr-2"></i>
                        Datos del Nuevo Permisos
                    </h3>
                </div>

                <div class="card-body">
                    <form action="<?php echo e(url('admin/roles/asignar',$rol->id)); ?>" method="post" >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="row">
                            <?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulo => $grupoPermisos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 mb-4">
                                    <h4 class="text-primary"><?php echo e(ucfirst($modulo)); ?></h4>
                                    <div class="border rounded p-3 shadow-sm">
                                        <?php $__currentLoopData = $grupoPermisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-check mb-2">
                                                <input
                                                    type="checkbox"
                                                    class="form-check-input"
                                                    id="permiso_<?php echo e($permiso->id); ?>"
                                                    name="permisos[]"
                                                    value="<?php echo e($permiso->id); ?>"
                                                        <?php echo e($rol->hasPermissionTo($permiso->name) ? 'checked' : ''); ?>

                                                >
                                                <label class="form-check-label" for="permiso_<?php echo e($permiso->id); ?>">
                                                    <?php echo e($permiso->name); ?>

                                                </label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>


                        <div class="form-group mt-5">
                            <div class="d-grid gap-2">
                                <button type="submit"
                                        class="btn btn-primary btn-lg shadow-sm"
                                        id="submitBtn">
                                    <i class="fas fa-save mr-2"></i> Registrar Rol
                                </button>
                                <a href="<?php echo e(route('admin.roles.index')); ?>"
                                   class="btn btn-outline-secondary btn-sm">
                                    <i class="fas fa-arrow-left mr-2"></i> Cancelar y Volver
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .card-header {
        border-bottom: 2px solid #007bff;
    }
    #roleName {
        border-radius: 0 0.25rem 0.25rem 0;
    }
    .input-group-text {
        transition: all 0.3s ease;
    }
    .input-group:focus-within .input-group-text {
        background-color: #0056b3;
    }
    #charCount {
        min-width: 70px;
        font-weight: 500;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const roleName = document.getElementById('roleName');
        const charCount = document.getElementById('charCount');
        const form = document.getElementById('roleForm');
        const submitBtn = document.getElementById('submitBtn');

        // Contador de caracteres
        const updateCharCount = () => {
            const length = roleName.value.length;
            charCount.textContent = `${length}/255`;
            charCount.style.color = length > 200 ? '#dc3545' : '#6c757d';
        };

        // Validación en tiempo real
        roleName.addEventListener('input', (e) => {
            // Eliminar espacios en blanco
            e.target.value = e.target.value.replace(/\s+/g, ' ');
            updateCharCount();
        });

        // Manejar envío del formulario
        form.addEventListener('submit', () => {
            submitBtn.disabled = true;
            submitBtn.innerHTML = `
                <span class="spinner-border spinner-border-sm" role="status"></span>
                Registrando...
            `;
        });

        // Inicializar contador
        updateCharCount();

        // Mostrar notificación de éxito si existe
        <?php if(session('success')): ?>
            Swal.fire({
                icon: 'success',
                title: '¡Éxito!',
                text: '<?php echo e(session('success')); ?>',
                timer: 3000,
                showConfirmButton: false
            });
        <?php endif; ?>
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectoPers\sysprestamos\resources\views/admin/roles/asignar.blade.php ENDPATH**/ ?>