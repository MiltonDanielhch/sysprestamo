<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Storage;

class BackupController extends Controller
{
    public function index(){
        $backups = Storage::disk('backups')->exists('') ? Storage::disk('backups')->files() : [];
        return view('admin.backups.index', compact('backups'));
        // $backups = Storage::disk('backups')->files();
        // return view('admin.backups.index', compact('backups'));
    }

    public function create()
    {
        try {
            $output = new \Symfony\Component\Console\Output\BufferedOutput();
            $exitCode = \Artisan::call('backup:run --only-db', [], $output);
            $outputText = $output->fetch(); // Captura la salida del comando

            dd([
                'exit_code' => $exitCode,
                'output' => $outputText
            ]);
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Error al crear el backup: ' . $e->getMessage());
        }
    }


}
